const { recettes } = require('../models/recettes');


exports.getRecette = async () => {
    return recettes.findAll();
}

exports.getRecetteById = async (id) => {
    return recettes.findOne({
        where: {
            id
        }
    });
}

exports.addRecette = (nom, ingredients) => {
    return recettes.create({nom, ingredients});
}

exports.deleteRecetteById = (id) => {
    return recettes.destroy({
        where: {
            id
        }
    });
}