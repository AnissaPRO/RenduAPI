const { Sequelize } = require('sequelize');
const app = require('./app');

const sequelize = new Sequelize('apirecipe', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
  });



app.listen(3008, () => {
    console.log(`Serveur lancé sur le port 3008`);
});

module.exports = sequelize;