const recettesService = require('../services/recettes');
const createError = require('http-errors');

exports.getRecettes = async (req, res) => {
   const recettes = await recettesService.getRecettes();
   res.json({success: true, data: recettes});
}

exports.getRecetteById = async (req, res, next) => {
   const recette = await recettesService.getRecetteById(req.params.id);
   if (recette) {
      res.json({success: true, data: recette});
   } else {
      next(createError(404, "Pas de recette trouvé sous cet id"));
   }
}

exports.addRecette = async (req, res, next) => {
   const recetteCreated = await recettesService.addRecette(req.body.title, req.body.date);
   if (recetteCreated) {
      res.status(201).json({success: true, id: recetteCreated.id});
   } else {
      next(createError(400, "Vérifier les arguments de la recette !"));
   }
}

exports.deleteRecetteById = async (req, res, next) => {
   try {
      await recettesService.deleteRecetteById(req.params.id);
      res.status(204).send();
   } catch(e) {
      next(createError(404, `La recette ayant pour attribut l'id '${id}' n'existe pas.`));
   }
}


exports.searchRecettes = async (req, res) => {
   const { q } = req.query; // 'q' est l'ingrédient à rechercher
   const resultats = await recettesService.findAll({
       where: {
         ingredients: {
           [sequelize.Op.like]: `%${q}%` // Recherche d'ingrédients contenant 'q'
         }
       }
     }); 
     if(resultats){
      res.json({success: true, data: resultats});
   } else {
     next(createError(404, 'Pas de recette trouvée avec contenant cet ingrédient.' ));
   }
 };