const express = require('express'),
      router = express.Router(),
      { authMiddleware } = require('../controllers/auth'),
      recettesController = require('../controllers/recettes');

router.get('/', recettesController.getRecettes);
router.get('/:id', recettesController.getRecetteById);
router.post('/', authMiddleware, recettesController.addRecette);
router.delete('/:id', recettesController.deleteRecetteById);
router.get('/search', recettesController.searchRecettes);

module.exports = router;