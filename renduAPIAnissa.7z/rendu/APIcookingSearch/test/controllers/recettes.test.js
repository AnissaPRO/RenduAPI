const request = require('supertest');
const app = require('../../app');
const recettesService = require('../../services/recettes');

// Globals mocks
const mockedRecettes = [{id: 1, name: "test"}, {id: 2, name: "toto"}, {id: 3, name: "tata"}, {id: 4, name: "titi"}];
jest.mock('../../services/recettes');
recettesService.addRecette.mockReturnValueOnce(true);

describe('get recettes endpoint', () => {

    it('on devrait retourner toutes les recettes', async () => {
        // Mock
        recettesService.getRecettes.mockReturnValueOnce(mockedRecettes);

        // When
        const resp = await request(app).get('/recettes');

        // Then
        expect(resp.statusCode).toEqual(200);
        expect(resp.body).not.toBeNull();
        expect(resp.body).toHaveProperty('data');
        expect(resp.body).toHaveProperty('success');
        expect(resp.body.success).toBeTruthy();
        expect(resp.body.data).toHaveLength(4);
    });

    it('succès attendu, la recette devrai être trouvée', async () => {
        // Mock
        recettesService.getRecetteById.mockReturnValueOnce(mockedRecettes[0]);

        // When
        const resp = await request(app).get('/recettes/10');
        
        // Then
        expect(resp.statusCode).toEqual(200);
        expect(resp.body).not.toBeNull();
        expect(resp.body).toHaveProperty('data');
        expect(resp.body).toHaveProperty('success');
        expect(resp.body.success).toBeTruthy();
    });

    it('échec attendu, recette non trouvée', async () => {
        // Mock
        recettesService.getRecetteById.mockReturnValueOnce(false);

        // When
        const resp = await request(app).get('/recettes/10');
        
        // Then
        expect(resp.statusCode).toEqual(404);
        expect(resp.body).not.toBeNull();
        expect(resp.body).not.toHaveProperty('data');
        expect(resp.body).toHaveProperty('success');
        expect(resp.body).toHaveProperty('message');
        expect(resp.body.success).toBeFalsy();
    });
});

describe('post recipes endpoint', () => {
    it('La recette devrai être ajoutée', async () => {
        // When
        const resp = await request(app).post('/recettes').set('Authorization', 'Bearer TOKEN').send({
            name: 'omelette',
            ingredients: 'oeuf sel'
        });

        // Then
        expect(resp.statusCode).toEqual(201);
        expect(resp.body).not.toBeNull();
        expect(resp.body).toHaveProperty('success');
        expect(resp.body.success).toBeTruthy();
    });

    it('Argument incomplet, échec attendu', async () => {
        // When
        const resp = await request(app).post('/recettes').set('Authorization', 'Bearer TOKEN').send({
            name: 'Biscuits secs'
        });

        // Then
        expect(resp.statusCode).toEqual(400);
        expect(resp.body).not.toBeNull();
        expect(resp.body).toHaveProperty('success');
        expect(resp.body).toHaveProperty('message');
        expect(resp.body.success).toBeFalsy();
    });
});

describe('search recipes endpoint', () => {
    it('devrait retourner les recettes correspondant à l\'ingrédient spécifié', async () => {
        // When
        const ingredientRecherche = 'sucre';
        const resp = await request(app).get(`/recettes/search?q=${ingredientRecherche}`);

         // Then
        expect(resp.statusCode).toEqual(200);
        expect(resp.body).not.toBeNull();
        expect(resp.body.length).toBeGreaterThan(0); 
    });

    it('devrait renvoyer une erreur si l\'ingrédient est manquant', async () => {
        
        // When
        const resp = await request(app).get('/recettes/search');

        // Then
        expect(resp.statusCode).toEqual(400);
        expect(resp.body).not.toBeNull();
        expect(resp.body).toHaveProperty('error');
    
    });
});
