const { DataTypes } = require ('sequelize');
const sequelize = require('../server');

const Recette = sequelize.define('recette', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  name: {
    type: DataTypes.STRING
  },
  ingredients: {
    type: DataTypes.STRING
  }
}, {
    timestamps: false
});
module.exports = Recette;

  